# -*- coding: utf-8 -*-

from . import purchase_order_line_analytic_account
from . import sale_order_analytic_account
