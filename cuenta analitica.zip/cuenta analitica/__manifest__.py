# -*- coding: utf-8 -*-
{
    'name': 'Modificación de cuenta analitica requerida',
    'version': '1.2',
    'category': 'Uncategorized',
    'sequence': 0,
    'author':'Qualsys consulting',
    'summary': '''Se modificaron los campos de cuenta analitica en los modelos de Compras y Ventas. 
    ''',
    'description':'''Cambios realizados en los módulos de: 
    Ventas: Se agrego la cuenta analítica como un campo requerido.
    Compras: Se agrego un la cuenta analítica como un campo requerido.
    ''',
    
    'website': 'https://www.qualsys.com.mx',
    'depends': ['purchase', 'sale_management'],
    'data': [
        #'security/purchase_security.xml',

    ],
    'demo': [
        #'data/purchase_demo.xml',
    ],
    'installable': True,
    'auto_install': False,
}