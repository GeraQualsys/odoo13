# -*- coding: utf-8 -*-
{
    'name': 'Modificación de modulo de Compras',
    'version': '1.2',
    'category': 'Uncategorized',
    'sequence': 0,
    'author':'Qualsys consulting',
    'summary': '''Se modifico el modulo de compras usando reglas de abastecimiento. 
    ''',
    'description':'''Cambios realizados en los módulos de: 
    Compras: Se modifico el modulo de Compras usando las reglas de abastecimiento que tiene el producto.
    ''',
    
    'website': 'https://www.qualsys.com.mx',
    'depends': ['stock', 'purchase'],
    'data': [
        #'security/purchase_security.xml',

    ],
    'demo': [
        #'data/purchase_demo.xml',
    ],
    'installable': True,
    'auto_install': False,
}