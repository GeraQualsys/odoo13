from odoo import fields, api, models
from odoo.exceptions import UserError, ValidationError

class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    test = fields.Float()
    picking_type_id=fields.Float('purchase.order')

    
    @api.onchange('product_qty')
    def _onchange_product(self):
        product_qty = fields.Float(string='Quantity', required=True)
        

        product_id = self.product_id
        reordering_max_qty = product_id.reordering_max_qty
        reordering_min_qty = product_id.reordering_min_qty
        qty_available = product_id.qty_available #producto en maximo stock
        #picking_type_id  lugar de entrega en purchase
        warehouse_ids= product_id.route_ids.warehouse_ids




        #orderpoint = product_max_qty.orderpoint  picking_type_id
        title = False
        message = False

        if (reordering_max_qty>=1):
            if (qty_available > reordering_max_qty):
                raise UserError(('El producto esta en su maximo stock'))

            if (self.product_qty > 1):
                if (self.product_qty > reordering_max_qty):
                    self.product_qty=False
                    #product_qty=self.qty_available - self.reordering_max_qty
                    raise UserError('Cantidad maxima para reabastecer es  %s' %reordering_max_qty)

            #if self.product_qty < reordering_min_qty:
                #self.product_qty=False
                #raise UserError('Cantidad minima para reabastecer es  %s' %reordering_min_qty)


