# -*- coding: utf-8 -*-
{
    'name': 'Modificación de fecha de validez y vencimiento',
    'version': '1.2',
    'category': 'Uncategorized',
    'sequence': 0,
    'author':'Qualsys consulting',
    'summary': '''Se agregaron campos de fecha de validez y fecha de vencimiento. 
    ''',
    'description':'''Cambios realizados en los módulos de: 
    Campos de: Fecha de validez agregado en las solicitudes de compras y Fecha de vencimiento de la cotización de compra.
    ''',
    
    'website': 'https://www.qualsys.com.mx',
    'depends': ['purchase', 'sale_management'],
    'data': [
        #'security/purchase_security.xml',
        'views/purchase_order_fecha.xml',
        'views/sale_order_fecha.xml',

    ],
    'demo': [
        #'data/purchase_demo.xml',
    ],
    'installable': True,
    'auto_install': False,
}